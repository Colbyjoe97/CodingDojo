class DojosController < ApplicationController
  def move
    redirect_to '/dojos'
  end

  def index
    session[:count] = 0
    for dojo in Dojo.all
      session[:count] += 1
    end
    @dojos = Dojo.all
  end

  def new
    render 'createPage'
  end

  def create
    @dojo = Dojo.create( dojo_params )
    redirect_to '/dojos'
  end

  private
  def dojo_params
    params.require(:dojo).permit(:branch, :street, :city, :state)
  end
end
