Rails.application.routes.draw do
  get '' => 'dojos#move'
  get 'dojos' => 'dojos#index'
end
