class Dojo < ActiveRecord::Base
    has_many :students
end
