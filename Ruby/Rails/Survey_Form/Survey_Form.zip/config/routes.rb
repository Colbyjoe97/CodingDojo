Rails.application.routes.draw do
  get '' => 'users#index'
  post 'submit' => 'users#submit'
  get 'result' => 'users#result'
end
