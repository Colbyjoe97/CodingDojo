FactoryBot.define do
  factory :user do
    first_name { "MyString" }
  end
end
