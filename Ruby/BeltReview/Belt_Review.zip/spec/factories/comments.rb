FactoryBot.define do
  factory :comment do
    content { "MyText" }
    user { nil }
    event { nil }
  end
end
