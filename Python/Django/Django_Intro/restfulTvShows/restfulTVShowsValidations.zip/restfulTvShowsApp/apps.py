from django.apps import AppConfig


class RestfultvshowsappConfig(AppConfig):
    name = 'restfulTvShowsApp'
