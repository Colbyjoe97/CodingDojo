from django.apps import AppConfig


class NumbergameappConfig(AppConfig):
    name = 'numberGameApp'
