from django.apps import AppConfig


class TimeappConfig(AppConfig):
    name = 'timeApp'
