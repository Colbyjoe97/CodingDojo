from django.apps import AppConfig


class BeltreviewappConfig(AppConfig):
    name = 'beltReviewApp'
