from django.apps import AppConfig


class FirstprojectappConfig(AppConfig):
    name = 'firstProjectApp'
