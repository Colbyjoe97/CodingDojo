from django.apps import AppConfig


class DojoninjasappConfig(AppConfig):
    name = 'dojoNinjasApp'
