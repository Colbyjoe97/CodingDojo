//Predict 1 answer: I was born in1980

//Predict 2 answer: I was born in1980

/*Predict 3 answer: 
Summing numbers!
num1 is: 10
num2 is: 20
30*/

