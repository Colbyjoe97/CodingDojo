const productController = require("../controllers/product.controller")

module.exports = app => {
    app.get("/api/product/all", productController.findAllProducts)
    app.post("/api/product/create", productController.createNewProduct)
}