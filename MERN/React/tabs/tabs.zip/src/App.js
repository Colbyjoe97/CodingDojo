import './App.css';
import Tab from './components/tabs'

function App() {
  return (
    <Tab />
  )
}

export default App;
