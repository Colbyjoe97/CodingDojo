import React, { useState } from 'react';

const UserForm = (props) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const createUser = (e) => {
        e.preventDefault();
        const newUser = { firstName, lastName, email, password}
        console.log("Welcome", newUser);
    };
    return(
        <>
            <div className="card col-5">
                <div className="card-body">
                    <h1 className="card-title text-center">Create User</h1>
                    <form onSubmit={ createUser }>
                        <div>
                            <label>First Name: </label>
                            <input className="form-control" type="text" onChange={ (e) => setFirstName(e.target.value) } />
                        </div>
                        <div>
                            <label>Last Name: </label>
                            <input className="form-control" type="text" onChange={ (e) => setLastName(e.target.value) } />
                        </div>
                        <div>
                            <label>Email: </label>
                            <input className="form-control" type="text" onChange={ (e) => setEmail(e.target.value) } />
                        </div>
                        <div>
                            <label>Password: </label>
                            <input className="form-control" type="text" onChange={ (e) => setPassword(e.target.value) } />
                        </div>
                        <div>
                            <label>Confirm Password: </label>
                            <input className="form-control" type="text" onChange={ (e) => setPassword(e.target.value) } />
                        </div>
                        <div>
                            <input className="btn-success mt-3" type="submit" value="Create User"></input>
                        </div>
                    </form>
                </div>
            </div>
            <div className="card">
                <div className="card-title">
                    <h3>Name: {firstName} {lastName}</h3>
                </div>
                <h6>Email: {email}</h6>
                <h6>Password: {password}</h6>
            </div>
        </>
    )
};

export default UserForm;