// import React, { Component } from 'react';

// class IncreaseAge extends Component {
    // constructor (props) {
    //     super (props);
    //     this.state = {
    //         age: this.props.age
    //     };
    // }
//     render() {
//         return(
//             addAge = () => {
//                 this.setState({ age: age + 1})
//             }
//         )
//     }
// }

// export default IncreaseAge;