namespace viewModelFun.Models
{
    public class StringPage
    {
        public string Str {get;set;}
    }
}