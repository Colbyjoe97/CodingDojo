using System.ComponentModel.DataAnnotations;

namespace DojoSurvey.Models
{
    public class Survey
    {
        public string name {get;set;}
        public string locations {get;set;}
        public string languages {get;set;}
        public string comment {get;set;}
    }
}