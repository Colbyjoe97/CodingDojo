using DojoSurvey.Models;
using Microsoft.AspNetCore.Mvc;

namespace DojoSurvey.Controllers
{
    public class ResultsController : Controller
    {
        [HttpPost("survey")]

        public IActionResult Results(Survey surv)
        {
            Survey form = new Survey();
            return View(surv);
        }
    }
}