using Microsoft.AspNetCore.Mvc;

namespace DojoSurvey.Controllers
{
    public class ResultsController : Controller
    {
        [HttpPost]
        [Route("results")]

        public IActionResult Method(string name, string locations, string languages, string comment)
        {
            ViewBag.name = name;
            ViewBag.loc = locations;
            ViewBag.lan = languages;
            ViewBag.comment = comment;
            return View("Results");
        }
    }
}