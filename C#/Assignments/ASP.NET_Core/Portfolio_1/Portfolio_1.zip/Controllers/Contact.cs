using Microsoft.AspNetCore.Mvc;
namespace Portfolio_1.Controllers
{
    public class Contact : Controller
    {
        [HttpGet]
        [Route("contact")]
        public string contact()
        {
            return "This is my contact page!";
        }
    }
}