using Microsoft.AspNetCore.Mvc;
namespace Portfolio_1.Controllers
{
    public class Projects : Controller
    {
        [HttpGet]
        [Route("projects")]
        public string projects()
        {
            return "This is my projects page!";
        }
    }
}