const mongoose = require('mongoose')
const Task = mongoose.model("Task")

module.exports = {
    // This fetches all data but doesn't let me pass it to the component.html to be
    // displayed on the webpage
    // index: function(req, res) {
    //     Task.find(err,)
    //         .then(data => res.json(data))
    //         .then(err => res.json(err))
    // },



// This one allows me to pass data to the component.html to be displayed on the page
    index: function(req, res) {
        Task.find({}, function(err, task) {
            if(err) {
                res.json({message: "Error on find: ", err})
            }
            else {
                res.json({message: "Successfully found tasks!", tasks: task})
            }
        })
    },

    getOne: function(req, res) {
        Task.find({_id: req.params.id})
            .then(data => res.json(data))
            .catch(err => res.json(err))
    },

    create: function(req, res) {
        const task = new Task()
        task.title = req.body.title
        task.description = req.body.description
        task.completed = req.body.completed
        task.save()
            .then(response => console.log("Task Created: ", response))
            .catch(err => console.log("Errors on create: ", err))
    },

    delete: function(req, res) {
        console.log("@@@@@@@@@@@@")
        console.log("Deleting ", req.params.id)
        console.log("@@@@@@@@@@@@")
        Task.deleteOne({_id: req.params.id})
            .then(result => result.json())
    },

    update: function(req, res) {
        Task.updateOne({_id: req.params.id}, req.body,
            {
                runValidators: true,
                new: true,
                useFindAndModify: false
            })
            .then(updatedTask => res.json({results: updatedTask}))
            .catch(err => res.json(err))
    }
}