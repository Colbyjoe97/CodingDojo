import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  pet: object
  petToEdit: any
  nameError: string
  typeError: string
  dupeError: string
  descriptionError: string
  pets = []
  petName = ""

  constructor(private _httpService: HttpService, private router:Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.dupeError = ""
    this.nameError = ""
    this.typeError = ""
    this.descriptionError = ""
    this.pet = {
      pet: {
        name: "",
        type: "",
        description: "",
        skill_one: "",
        skill_two: "",
        skill_three: ""
      }
    }
    this.petToEdit = {
        name: "",
        type: "",
        description: "",
        skill_one: "",
        skill_two: "",
        skill_three: ""
    }
    this.getPet()
    this.getPets()
  }

  getPets() {
    const observable = this._httpService.getPets()
    observable.subscribe(data => {
      console.log("Getting all pets.. ", data)
      this.pets = data["pets"]
      console.log("All Pets: ", this.pets)
    })
  }
  
  getPet() {
    this._route.params.subscribe((params) => {
      console.log("Pet ID is.. ", params["id"])
      const observable = this._httpService.onePet(params["id"])
      observable.subscribe(data => {
        console.log("Pet data: ", data)
        this.pet = data
        this.petToEdit = this.pet
        this.petName = this.petToEdit.name
      })
    })
  }

  editPet() {
    console.log(this.petToEdit)
    this.dupeError = ""
    this.nameError = ""
    this.typeError = ""
    this.descriptionError = ""
    for(let p of this.pets) {
      console.log(p)
      if(this.petToEdit.name == p.name) {
        this.dupeError = "Pet name already exists!"
      }
    }
    if(this.dupeError == "") {
      this._route.params.subscribe((params) => {
        const observable = this._httpService.edit(params["id"], this.pet)
        observable.subscribe((data: any) => {
          if(data.errors) {
            if(data.errors.name) {
              console.log("Errors on edit: ", data.errors)
              this.nameError = data.errors.name.message
            }
            if(data.errors.type) {
              console.log("Errors on edit: ", data.errors)
              this.typeError = data.errors.type.message
            }
            if(data.errors.description) {
              console.log("Errors on edit: ", data.errors)
              this.descriptionError = data.errors.description.message
            }
          }
          else {
            this.router.navigate(['/pets'])
          }
        })
      })
    }
  }
}