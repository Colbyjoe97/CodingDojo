const express = require("express");
const app = express();
const mongoose = require('mongoose');
const flash = require('express-flash');
var session = require("express-session");
var bodyParser = require("body-parser");
app.use(flash())
app.use(bodyParser.urlencoded({entended: true}));
app.use(express.static(__dirname + "/static"));
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.use(session({
    secret: 'codingdojo',
    resave: false
}))

mongoose.connect('mongodb://localhost/quotesDB', {useNewUrlParser: true});


const QuoteSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Name is required"]
    },
    quote: {
        type: String,
        required: [true, "Quote is required"],
        minLength: [5, "Quote must be at least 5 characters long"]
    }
}, {timestamps: true})
const Quote = mongoose.model('Quote', QuoteSchema)


require('./server/config/routes')(app)


app.listen(8000, () => console.log("The server is all fired up on port 8000"));