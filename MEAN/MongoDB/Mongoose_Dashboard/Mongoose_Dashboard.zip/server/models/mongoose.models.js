const { Mongoose } = require("mongoose");

const MongooseSchema = new Mongoose.Schema({
    name: {
        type: String,
        required: [true, "Name is required"]
    },
    age: {
        type: Number,
        required: [true, "Age is required"]
    }
}, {timestamps: true})

const Mong = mongoose.model('Mongoose', MongooseSchema)