module.exports = {

    // index: (req, res) => {
    //     res.redirect("/")
    // }

}