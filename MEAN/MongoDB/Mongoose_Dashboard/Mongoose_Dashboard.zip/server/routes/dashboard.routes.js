const Dash = require('../controller/dashboard.controller')

module.exports = function(app) {

    app.get('/', (req, res) => {
        Dash.index(req,res)
    })


}