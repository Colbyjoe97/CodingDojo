const express = require("express");
const app = express();
const mongoose = require('mongoose');
var session = require("express-session");
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({entended: true}));
app.use(express.static(__dirname + "/static"));
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

require('./server/config/mongoose.config')
require('./server/routes/dashboard.routes')
app.use(session({
    secret: 'codingdojo',
    resave: false
}))

mongoose.connect('mongodb://localhost/mongooseDB', {useNewUrlParser: true});

const MongooseSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Name is required"]
    },
    age: {
        type: Number,
        required: [true, "Age is required"]
    }
}, {timestamps: true})

const Mong = mongoose.model('Mongoose', MongooseSchema)


app.get('/', (req, res) => {
    Mong.find()
        .then(data => res.render('index', {mongoose: data}))
        .catch(err => res.json(err))
})

app.get('/mongooses/new', (req, res) => {
    res.render("create")
})

app.get('/delete/:id', (req, res) => {
    Mong.deleteOne({_id: req.params.id})
        .then(res.redirect('/'))
})

app.get('/view/:id', (req, res) => {
    Mong.findOne({_id: req.params.id})
        .then(data => res.render('view', {mongoose: data}))
        .catch(err => res.json(err))
})

app.get('/editPage/:id', (req, res) => {
    Mong.findOne({_id: req.params.id})
        .then(data => res.render('edit', {mongoose: data}))
        .catch(err => res.json(err))
})

app.post('/edit/:id', (req, res) => {
    Mong.updateOne({_id: req.params.id}, req.body,
        {
            runValidators: true,
            new: true,
            useFindAndModify: false
        })
        .then(updatedMongoose => res.json({results: updatedMongoose}))
        .catch(err => res.json(err));
        res.redirect('/')
})

app.post('/addMongoose', (req, res) => {
    const mongoose = new Mong()
    mongoose.name = req.body.name;
    mongoose.age = req.body.age;
    mongoose.save()
        .then(response => console.log("Mongoose Created", response))
        .catch(err => console.log("There's an error!", err))

    res.redirect("/")
})




app.listen(8000, () => console.log("The server is all fired up on port 8000"));